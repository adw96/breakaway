library("testthat")
packageVersion("breakaway")
test_check("breakaway")