###### bettademo.R, a script to introduce you to the package "breakaway"
###### for alpha diversity estimation and comparison
###### Software authors: Amy Willis and Kathryn Barger
###### Theory & paper authors: Amy Willis, Kathryn Barger & John Bunge, 2013-15

## Start by checking what directory you are in with
getwd()
## Set it to your local copy of diversitylab with setwd("[folder/diversitylab]")

## Load the package we need. It's called breakaway. It's awesome.
## Conflicts of interest alert: I wrote it.
## An old version is available via CRAN using install.packages("breakaway")
## The latest version is EXCLUSIVELY available to you RIGHT HERE
## at STAMPS. You can load it using
install.packages("breakaway_4.0.tar.gz", type="source", repos=NULL)
require("breakaway")
## If the above didn't work, check that the file is in the same location
## as getwd()
## If that didn't work, check you can connect to the internet, have
## a look at your CRAN mirror settings...
## If you're still having trouble, call a TA over!

#### Load the species abundance table and metadata
data <- read.table("mask_data.txt",header=T)
metadata <- read.table("mask_meta.txt",header=T)
## If an error was thrown, that means that the data was not in the
## working directory. Ensure that the data is in filepath specified by
## getwd(), or setwd([where you have saved your data])

## This is data from 63 different lakes.

## Have a look at the first few rows/columns your data and your metadata
data[1:4,1:4]
metadata[1:4,]
## data is very big! To see how big, go
dim(data)

## Huh? Levels? What type of object is Year, anyway?
class(metadata$Year)
## Year is what's called a "Factor," i.e. a categorical variable. But
## what if we want to consider it as a continuous variable? We need to
## force it into a numeric. We do this as follows
Year_num <- as.numeric(substr(as.character(metadata$Year),4,5))
Year_num
## Feel like you're falling behind? Don't stress! If you want to learn the
## details you can go back later and figure out exactly what the functions
## as.character, substr, and as.numeric all do, and why I chose to combine
## them in this way.

## Take a moment to congratulate yourself on loading a package,
## opening data, and exploring the dataset! That's huge! Woohoo!

##### CREATE FREQUENCY TABLES

## We're now going to "collapse" the data's columns (samples) into frequency tables
## We use several functions here: table, apply, as.data.frame and lapply
## If you're interested, you should explore these later. We want to analyse
## the data right now!
frequencytablelist <- lapply(apply(data,2,table),as.data.frame)
frequencytablelist <- lapply(frequencytablelist,function(x) x[x[,1]!=0,])

## Have a look at the frequency tables ("frequency count data"). I've put them
## in a list so we need to use double square brackets [[63]] to refer to the 63rd one
frequencytablelist[[63]]
## Interpretation: In this sample, there were 57 different species observed
## only once (singletons), 25 different species observed only twice, ...,
## 1 species observed 171 times

##### ESTIMATE SPECIES RICHNESS
## Let's run breakaway on the first frequency count table
breakaway(frequencytablelist[[1]])
## You should get some output to screen, including your estimate & s.e., and a
## plot of the fits to the ratios. Note that it is not a fit to the frequencies,
## it is a fit to the ratios of frequencies. You would never need to include
## this type of plot in one of your papers. It is solely for you to check
## for model misspecification. What's model misspecification? If the black
## diamonds don't remotely follow the pattern of the white circles, that's
## model misspecification.

## The reference for breakaway is
## Willis, A. and Bunge, J. (2015). Estimating Diversity via Frequency Ratios. Biometrics 71 1042-1049.
## Feel free to email me with questions!

## Sometimes, breakaway's usual procedure doesn't work, that is, it gives
## a negative estimate, which is of course silly. In that case, breakaway
## returns a different model's result. It's called the WLRM. There isn't a
## picture. Here is an example of a case where breakaway returns the WLRM.
breakaway(frequencytablelist[[60]])
## breakaway can defer to the WLRM for several reasons. Perhaps there are
## too many singletons. Perhaps there isn't a long enough tail. Perhaps
## there is false diversity. In this case, there was probably not enough data.
## Let's see if this failure was sensitive to the singleton count by running
## breakaway_nof1. This requires no singleton count (implicit is that the
## singleton count was erroneous) and predicts it from the other frequencies.
## Here is an example.
breakaway_nof1(frequencytablelist[[60]][-1,])

## The reference for this method:
## Willis, A. (2016). Species richness estimation with high diversity but spurious singletons.

## breakaway_nof1 is an exploratory tool for assessing sensitivity of
## breakaway to the singleton count. You should not use it for diversity
## estimation -- only diversity *exploration* :)




## Let's move on to looking at the Objective Bayes procedures of
## Kathryn Barger. It's the latest and greatest in diversity estimation!

## There are 4 different types of objective bayes estimates, due to
## 4 different models. If you have time play with all of them!
## For now we are just going to look at the negative binomial.

#objective_bayes_poisson(frequencytablelist[[60]])$results
#objective_bayes_geometric(frequencytablelist[[60]])$results
#objective_bayes_mixedgeo(frequencytablelist[[60]])$results

install.packages("MASS"); require(MASS) ## you need MASS for this to work
objective_bayes_negbin(frequencytablelist[[1]])
## (Don't worry about those warnings. We're working on them -- sorry!)

## That's a lot of information! Bayesians are very good at generating
## a lot of information. This is because rather than a single estimate
## you see the distribution of estimates (remember that the Bayesian
## paradigm believes the parameter to be random => it has a distribution)


## Let's talk about some of the information:
# $results mode.N/mean.N/median.N : the mode/mean / median estimate
# $results L/UCI.N:  A 95% percent interval estimate for the richness
# The picture at the bottom: The distribution of estimates

## The reference for this method is
## Barger & Bunge. (2010). Objective Bayesian estimation for the number
##    of species. Bayesian Analysis. 5(4), 765-785.

## EVENNESS

## The above discussion focused exclusively on richness. Let's look at
## the variability of evenness estimates

## Let's calculate the plug in estimate of Shannon diversity
shannon(frequencytablelist[[1]])

## 4.95, huh? Let's look at how variable it is
set.seed(2) # the following functions are random, so let's set the seed (allows reproducibility)
resample_estimate(data[,1], shannon)
resample_estimate(data[,1], shannon)
resample_estimate(data[,1], shannon)

## Hmmm, doesn't look too variable! Let's look at a lot of them
par(mfrow=c(1,1))
hist(replicate(200, resample_estimate(data[,1], shannon)))
## (replicate says: "do this 200 times")
## Yikes, that's some negative skew! That suggests that we have
## risks in randomly observing really low Shannon diversity estimates
## This is an important thing to keep in mind when analysing data
## eg. Did we just have bad luck with the sample from the patient
##     taking the drug? Or is the drug causing the effect?

## BTW, you can use the above to look sample size variability as well
## If you have very different numbers of reads across samples, this can$
## introduce additional variability. Let's look at the distribution
## of reads in the current dataset.
ns <- unlist(lapply(frequencytablelist, function(x) sum(x[,2])))
hist(ns)
## Well, but a lot of variability! Lets account for it in looking at
## our distribution of Shannon diversity estimates
set.seed(8)
hist(replicate(500, resample_estimate(data[,1], shannon, my_sample_size = ns)))
## That's a lot more variability than we saw originally!

## Going forward with your analyses, don't forget to account for
## variability in your estimates. Bootstrap standard errors are better
## than nothing!
sd(replicate(500, resample_estimate(data[,1], shannon, my_sample_size = ns)))


###### COMPARISONS

## We spent a lot of time looking at each sample'salpha diversity values

## Let's do some comparisons across samples... accounting for variability
## of course!

## We're going to do this procedure for shannon evenness, and estimate
## it using the plug-in estimate. This is not meant to imply that you should 
## be interested in Shannon! Just that some people are.

## Feel free to substitute in whatever alpha diversity/evenness/richness
## procedure you're interested in!

## To do this we will start by iterating on Shannon on every one of our samples.
## It may take a minute or two to run. Feel like a stretch? Go ahead!

## This section may take a while. Do you know if your neighbour likes bagels?
## Would they order a croissant over a bagel? Now is a great time to find out!
estimates_shannon <- matrix(NA,nrow=dim(data)[2],ncol=4)
rownames(estimates_shannon) <- colnames(data)
colnames(estimates_shannon) <- c("shannon_est","shannon_seest","shannon_lcb","shannon_ucb")
for (i in 1:dim(data)[2]) {
  #resample_estimate(data[,i], shannon, my_sample_size = ns)
  samples <- replicate(500, resample_estimate(data[,i], shannon, my_sample_size = ns))
  estimates_shannon[i,1] <- mean(samples)
  estimates_shannon[i,2] <- sd(samples)
  estimates_shannon[i,3:4] <- quantile(samples, c(0.025, 0.975))
}
## Here gives us our estimates and standard errors so we can have a look
estimates_shannon[,1:2]
## We can even (normal-ish) plot intervals. The x-axis is just against the
## enumeration of the lakes. It is not meaningful.
## The following plotting command may be different to ones you have seen
## before. It's a really quick way of visualizing the error in your samples
## and quickly spotting outliers. NOTE: Outliers have SMALL LINES, which means
## high precision, and are generally far away from points near them.
betta_pic(estimates_shannon[,1], estimates_shannon[,2])

## No obvious outliers here.

## Lets look at the effect of summer samples
col_by_seasons <- ifelse(metadata$Season=="Autum","black",ifelse(metadata$Season=="Spring","pink","red"))
betta_pic(estimates_shannon[,1], estimates_shannon[,2], mycol = col_by_seasons)
legend("bottom",c("Spring","Summer","Autumn"),col=c("pink","red","black"),cex=0.8,lwd=3,box.col=F)
## Don't forget that because we are plotting diversity *estimates*, we
## need to plot *lines* (i.e. confidence intervals) not points (point
## estimates). That's very important.


## We're now going to create our "design" matrix, a.k.a. "X matrix."
## To do this we're going to cheat a little. We're going to use an
## existing R method, lm, to save us the hassle.
## We are going to investigate the effect of temperature and site
covar_matrix <- model.matrix(lm(rnorm(dim(metadata)[1])~metadata$Site*(metadata$Season=="Summ")))
head(covar_matrix)
colnames(covar_matrix) <- c("Int", "SiteP", "Summer", "SitePSummer")
## Details (skip if uninterested): lm(y~x+z) is a function that fits a
## regression line to y using the variables x and z. It has a very nice
## interface that saves you doing the hard work (aka "math") to create your
## design matrix. The function we are going to use has no such nice interface.
## For that reason, we steal the design matrix out of lm()'s implementation.
## lm(y~x*z) looks at interactions. In this case, we are seeing if the
## evenness trend as a function of temperature changes depending on the site

## Easter egg: if you can put your own data (from your own research) in the
## *exact* same form as the above example, you don't need to understand what
## happens below. You can just copy it :)
## Hint: The biggest problem you may have in implementing the above is
## the ordering of the data and the metadata. The following:
colnames(data)==rownames(metadata)
## being true in every spot is a necessary but not sufficient condition for
## the following to work properly.

#### MODEL SPECIES RICHNESS, TEST SIGNIFICANCE, INTERPRET RESULTS
## Let's go ahead and try to fit our model
results <- betta(estimates_shannon[,1],estimates_shannon[,2],covar_matrix)
## Let's take a look at the results
results$table
## Interpretation is idential to regression.

## Here are some things to quickly note:
## Firstly, significance of Summer means that the average
## Shannon diversity of the summer samples is significantly
## less than non-summer AT SITE L. It's less by 0.42 on
## average.

## The non-signif of the SiteP variables means there
## is no significant difference between Sites P and L,
## in both summer and not... AFTER ACCOUNTING FOR 
## ESTIMATION ERROR!

## Notice that a regression on the Shannon estimates
## notes more evidence against the "site has no affect" null:
summary(lm(estimates_shannon[,1] ~ metadata$Site*(metadata$Season=="Summ")))$coef[,c(1,4)]
## Not such a big deal in this case, but may be with more
## marginal results/more variables.

## You should always use betta() when modelling and doing
## inference on functions of your OTU table!

## sigsq_u (in full results output) being significant means there is still *heterogeneity*
## in the lakes. "Not all lakes have the same Shannon diversity
## even after accounting for season & site."
##  (microscale heterogeneity, pH, chemical factors, depth...?)


## If you are unfamiliar with regression analysis, we would recommend
## taking an introductory course in regression analysis. You will
## not regret it (after some period of time)!

####### Congratulations! You have finished almost all of the tutorial!

## An important note: I'm not pushing Shannon.
## You can repeat all of the above analysis with your own
## favourite index. Suppose I am more interested in
## Simpson, or inverse Simpson, or Shannon adjusted for population size.
## Here is how I would do this:

## Define a function to take otu columns and estimate
## the Simpson index using the plug-in estimate
simpson  <-  function(data) {
  data <- data/sum(data)
  sum(data^2)
}

## Exercise: define a function to calculate the inverse
## of the plug-in Simpson index  estimate

## To estimate the bootstrap mean and standard error
## of the simpson index, we do the following
simpson_resamples <- replicate(100, resample_estimate(data[,1], simpson))
hist(simpson_resamples)
mean(simpson_resamples)
sd(simpson_resamples)

## this is just for the first column
## you would do this for every sample (in a loop)
## then use these as inputs to betta

## The below shows you how to run CatchAll and read the output into R
## CatchAll is very fussy, because it was built for an outdated operating system
##

##### CATCHALL
## CatchAll is computionally intensive. For this reason, we will run it
## on only 4 of the samples.
## We are going to create a directory to write our frequency tables to,
## write our frequency tables, run CatchAll on them, read the CatchAll
## output back into R, then analyze the same data again using the
## CatchAll richness estimates

## We are going to be clever and run command line commands via
## R. So the below command is equivalent to writing "mkdir catchalltables"
## in the command line.
system("mkdir catchalltables")
for (i in 1:4) {
  tmp <- frequencytablelist[[i]] ## catchall is really fussy! Need numbers not strings/factors
  tmp2 <- cbind(as.numeric(levels(tmp[,1]))[-1],tmp[,2])
  write.table(tmp2,paste(getwd(), "/catchalltables/",
                         names(frequencytablelist)[i],".csv",sep=""),sep=",",row.names = FALSE,col.names = FALSE)
}
system("cp runcatchall.sh catchalltables")
system("cp CatchAllCmdL.exe catchalltables")
## This next step runs CatchAll on every file; it may take a few minutes
system("cd catchalltables; ./runcatchall.sh")

### IF THIS DIDN'T WORK *and* YOU WANT TO LEARN TO USE CATCHALL**
## 1. If you're on a Ma/Unix: You probably don't have mono (an emulator)
##    Go to http://www.mono-project.com/ and install it. 
## 2. If you're on Windows: Hmmm. You're going to need a different version. 
##    Download CatchAllcmdW.exe from http://www.northeastern.edu/catchall/downloads.html
##    Then run CatchAllcmdW.exe [inputfilename] [outputpath]
## 3. If neither of the above help: Sorry! Call me/a TA over. Or, come back to
##    it later and open up butterfly_BestModelsAnalysis.csv (an example output)
##    to see

## ** If CatchAll isn't so important, feel free to check out. You've learnt
## a lot already!

## We just ran CatchAll without interfacing with the command line.
## Woohoo! Now we'll read them in.

## We tell R to search in the directory "catchalltables" for any files ending
## in "*BestModelsAnalysis.csv" We then pull out the relevant columns
## into a matrix called estimates_catchall
txt.sources = list.files(path=paste(getwd(),"/catchalltables/",sep=""),
                         pattern="*BestModelsAnalysis.csv",recursive=TRUE)
myread <- function(x)  {
  y <- read.csv(paste("catchalltables/",x,sep=""),stringsAsFactors=FALSE)
  return(as.numeric(y[1,4:7]))
}
estimates_catchall <- matrix(sapply(txt.sources,myread),byrow=TRUE,ncol=4)
rownames(estimates_catchall) <- paste("Sample", 1:4, sep="")
colnames(estimates_catchall) <- c("catchall_est","catchall_seest","catchall_lcb","catchall_ucb")
estimates_catchall

## We can now run betta in the same way!
betta(estimates_catchall[,1], estimates_catchall[,2])$table
## Note that these estimates are homogeneous (all the same!)
## probably because there are only 4
## Here we haven't included any covariates (it's unlikely that we
## could find anything meaningful with 4 data points), but if you did
## this with your own data you would include covariates in the same
## way that we did for breakaway.

## THANKS FOR STAYING THROUGH TO THE END! I'd love to hear if you
## hated it/loved it/worst day ever -- please give me feedback to 
## better help you!! :) Amy
